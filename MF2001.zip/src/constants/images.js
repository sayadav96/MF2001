import spoon from '../assets/spoon.svg';
import sign from '../assets/sign.png';

export default {
  spoon,
  sign,
};